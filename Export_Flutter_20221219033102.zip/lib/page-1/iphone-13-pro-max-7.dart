import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax7knu (7:311)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupkvkrRPF (EnwaaSnodNnV7KdGT7kvkR)
              padding: EdgeInsets.fromLTRB(14*fem, 21*fem, 2*fem, 84*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupvmrs7G5 (EnwW8aCV4g52B6qgS4VMRs)
                    margin: EdgeInsets.fromLTRB(321*fem, 0*fem, 0*fem, 16*fem),
                    width: 59*fem,
                    height: 57*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // ellipse3PjP (7:328)
                          left: 2*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 57*fem,
                              height: 57*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(28.5*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/ellipse-3-bg-ums.png',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // ellipse4ddj (7:329)
                          left: 0*fem,
                          top: 35*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20*fem,
                              height: 20*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(10*fem),
                                  color: Color(0xff28e824),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f000000),
                                      offset: Offset(0*fem, 4*fem),
                                      blurRadius: 2*fem,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupwfn9Ggh (EnwWHjbtH9k7SWpZyuwFn9)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 30*fem),
                    padding: EdgeInsets.fromLTRB(82*fem, 82*fem, 36*fem, 50*fem),
                    width: 399*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(13*fem),
                      gradient: LinearGradient (
                        begin: Alignment(-1, -0.91),
                        end: Alignment(1, 1),
                        colors: <Color>[Color(0xfff99601), Color(0xc6fc8d36), Color(0xfff26b02), Color(0xfff26b02)],
                        stops: <double>[0, 0.412, 0.723, 1],
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupwgstEmw (EnwWZUeeut28aYUjTkWgsT)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                          width: double.infinity,
                          height: 86*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // 8MX (7:318)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                                child: Text(
                                  '\$',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 32*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Container(
                                // autogrouprdspngy (EnwWfe93uqYeV6Rsn1rDsP)
                                width: 257*fem,
                                height: double.infinity,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // walletbalanceJfK (7:317)
                                      left: 32*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 125*fem,
                                          height: 24*fem,
                                          child: Text(
                                            'Wallet Balance',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // M7o (7:327)
                                      left: 0*fem,
                                      top: 18*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 257*fem,
                                          height: 68*fem,
                                          child: RichText(
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 40*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: '34,649',
                                                  style: SafeGoogleFont (
                                                    'Impact',
                                                    fontSize: 58*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1625*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: '.',
                                                  style: SafeGoogleFont (
                                                    'Impact',
                                                    fontSize: 40*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1625*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: '60',
                                                  style: SafeGoogleFont (
                                                    'Impact',
                                                    fontSize: 32*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1625*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupzk6d2mf (EnwWo46NAgJQHqZQwSZk6d)
                          margin: EdgeInsets.fromLTRB(65*fem, 0*fem, 106*fem, 0*fem),
                          width: double.infinity,
                          height: 29*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfff8b551),
                            borderRadius: BorderRadius.circular(13*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Top Up',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.5*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // line4fJq (7:330)
                    margin: EdgeInsets.fromLTRB(12*fem, 0*fem, 19*fem, 8*fem),
                    width: double.infinity,
                    height: 3*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe7d1af),
                    ),
                  ),
                  Container(
                    // airtimekbB (7:326)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 328*fem, 3*fem),
                    child: Text(
                      'Airtime',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xfff99601),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupmcpjdQ5 (EnwX1YjYjWaoHmMMR4McPj)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 14*fem, 38*fem),
                    padding: EdgeInsets.fromLTRB(72*fem, 2*fem, 3*fem, 3*fem),
                    width: double.infinity,
                    height: 52*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(13*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 1*fem),
                          blurRadius: 4*fem,
                        ),
                      ],
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // buye4H (7:322)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 95*fem, 0*fem),
                          child: Text(
                            'Buy',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupzvcdKw7 (EnwXDD4nTkiNMZh2fEZVCd)
                          width: 195*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff99601),
                            borderRadius: BorderRadius.circular(13*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Sell ',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.5*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouptbffnZo (EnwXNCoo7KA6S9nGMztbFf)
                    margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 15*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupxgrxg9P (EnwXsSU5iP6hh4aHPyxgRX)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 392*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // autogroupebnhmgd (EnwY2wCG4hEXL8LUe1eBNH)
                                margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 95*fem, 1*fem),
                                width: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // amountsjf (7:324)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 154*fem, 0*fem),
                                      child: Text(
                                        'Amount',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xfff99601),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // networkMPw (7:325)
                                      'Network',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff99601),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupu6xb4p9 (EnwY2wCG4hEXLAXxWVU6XB)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
                                width: double.infinity,
                                height: 49*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // rectangle4ZW1 (7:364)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                                      width: 196*fem,
                                      height: 49*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(6*fem),
                                        color: Color(0xfffff1de),
                                      ),
                                    ),
                                    Container(
                                      // autogroup1dn1T5b (EnwY8gXgeMgdGekyD31dn1)
                                      padding: EdgeInsets.fromLTRB(133*fem, 18*fem, 15*fem, 18*fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xfffff1de),
                                        borderRadius: BorderRadius.circular(6*fem),
                                      ),
                                      child: Align(
                                        // polygon1kKb (7:366)
                                        alignment: Alignment.centerRight,
                                        child: SizedBox(
                                          width: 21*fem,
                                          height: 13*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/polygon-1.png',
                                            width: 21*fem,
                                            height: 13*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupwag9Rgd (EnwYFgL2UuMy7LANkjwAG9)
                                width: double.infinity,
                                height: 71*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // phonenumberYFT (7:323)
                                      left: 4*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 123*fem,
                                          height: 24*fem,
                                          child: Text(
                                            'Phone Number',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff99601),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // rectangle3QHf (7:363)
                                      left: 0*fem,
                                      top: 22*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 392*fem,
                                          height: 49*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(6*fem),
                                              color: Color(0xfffff1de),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // rectangle195eh (7:349)
                          width: 8*fem,
                          height: 195*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(13*fem),
                            color: Color(0xfff99601),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupbevdoKo (EnwYmkJFvZTQJNQf2AbEvD)
                    margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 15*fem, 0*fem),
                    width: double.infinity,
                    height: 47*fem,
                    decoration: BoxDecoration (
                      color: Color(0xfff99601),
                      borderRadius: BorderRadius.circular(9*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Sell',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.5*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9wcqq1b (EnwYyucfMZH4veRHoc9Wcq)
              padding: EdgeInsets.fromLTRB(24*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 72*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(8*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x1e000000),
                    offset: Offset(0*fem, -4*fem),
                    blurRadius: 6*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupc9quG6u (EnwZFV13RNKisrBoSMc9Qu)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 5*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // homesvgrepocom1Zrh (7:360)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.61*fem),
                          width: 34*fem,
                          height: 27.78*fem,
                          child: Image.asset(
                            'assets/page-1/images/home-svgrepo-com-1.png',
                            width: 34*fem,
                            height: 27.78*fem,
                          ),
                        ),
                        Container(
                          // homeqZK (7:342)
                          margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'Home',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupba57vqf (EnwZZDzUs7N8FnXo5FbA57)
                    width: 81*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // datasvgrepocom1eWm (7:332)
                          left: 24*fem,
                          top: 23*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/data-svgrepo-com-1.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // dataWYy (7:341)
                          left: 30*fem,
                          top: 55*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20*fem,
                              height: 12*fem,
                              child: Text(
                                'Data',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle25a33 (7:558)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 81*fem,
                              height: 72*fem,
                              child: Opacity(
                                opacity: 0.17,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0x2bf99601),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupkt9xENV (Enwa13anqN5kBmZwFvkt9X)
                    padding: EdgeInsets.fromLTRB(33.2*fem, 17*fem, 12*fem, 3*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupgfxfwXo (EnwZhtQiNqM7xiqj5qgfXf)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                          width: 31.8*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // airtimeSzM (7:338)
                                left: 0.7954101562*fem,
                                top: 40*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31*fem,
                                    height: 12*fem,
                                    child: Text(
                                      'Airtime',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 8*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff26b02),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // talkingbyphonesvgrepocom1Zhb (7:343)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31.59*fem,
                                    height: 40*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/talking-by-phone-svgrepo-com-1.png',
                                      width: 31.59*fem,
                                      height: 40*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogrouphpvm1Zb (EnwZmU95aZoUUUVFnEhpvM)
                          margin: EdgeInsets.fromLTRB(0*fem, 3.52*fem, 51*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // depositsvgrepocom1uus (7:353)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.52*fem),
                                width: 35*fem,
                                height: 31.96*fem,
                                child: Image.asset(
                                  'assets/page-1/images/deposit-svgrepo-com-1.png',
                                  width: 35*fem,
                                  height: 31.96*fem,
                                ),
                              ),
                              Container(
                                // depositzgR (7:339)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                                child: Text(
                                  'Deposit',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupvpiz5bP (EnwZpiYfeTo6caMUnTVPiZ)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // logoutsvgrepocom1xv5 (7:350)
                                margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 37*fem,
                                    height: 37*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/log-out-svgrepo-com-1-mb7.png',
                                      width: 37*fem,
                                      height: 37*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // logout1NZ (7:340)
                                'Log out',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}