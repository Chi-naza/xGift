import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax101SH (7:561)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupo99sVsF (EnwgiX4Vm6qnaFhY2Co99s)
              width: double.infinity,
              height: 854*fem,
              child: Stack(
                children: [
                  Positioned(
                    // autogroupwgbkCWm (EnwdH2xZ85PrZUke23wGBK)
                    left: 14*fem,
                    top: 99*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(82*fem, 82*fem, 36*fem, 50*fem),
                      width: 399*fem,
                      height: 256*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(13*fem),
                        gradient: LinearGradient (
                          begin: Alignment(-1, -0.91),
                          end: Alignment(1, 1),
                          colors: <Color>[Color(0xfff99601), Color(0xc6fc8d36), Color(0xfff26b02), Color(0xfff26b02)],
                          stops: <double>[0, 0.412, 0.723, 1],
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup6gkqXhT (EnwdZcKGbPphdds4jL6gkq)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                            width: double.infinity,
                            height: 86*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // pgZ (7:568)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                                  child: Text(
                                    '\$',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 32*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupvqrwHq3 (EnwdhGmAhcRWDcq5fPVQRw)
                                  width: 257*fem,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // walletbalanceccR (7:567)
                                        left: 32*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 125*fem,
                                            height: 24*fem,
                                            child: Text(
                                              'Wallet Balance',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // soF (7:577)
                                        left: 0*fem,
                                        top: 18*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 257*fem,
                                            height: 68*fem,
                                            child: RichText(
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 40*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: '34,649',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 58*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: '.',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 40*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: '60',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 32*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupewzmwKF (EnwdqSCEWaiQN5U48iEWzm)
                            margin: EdgeInsets.fromLTRB(65*fem, 0*fem, 106*fem, 0*fem),
                            width: double.infinity,
                            height: 29*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff8b551),
                              borderRadius: BorderRadius.circular(13*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Top Up',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // deposity13 (7:576)
                    left: 25*fem,
                    top: 396*fem,
                    child: Align(
                      child: SizedBox(
                        width: 63*fem,
                        height: 24*fem,
                        child: Text(
                          'Deposit',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupyyt7p1f (Enwd6YG3NFsqoTeXhVYyT7)
                    left: 349*fem,
                    top: 23*fem,
                    child: Container(
                      width: 59*fem,
                      height: 57*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse3VtV (7:578)
                            left: 2*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 57*fem,
                                height: 57*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(28.5*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-3-bg-Try.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse4YLy (7:579)
                            left: 0*fem,
                            top: 35*fem,
                            child: Align(
                              child: SizedBox(
                                width: 20*fem,
                                height: 20*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    color: Color(0xff28e824),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // line4mUd (7:580)
                    left: 26*fem,
                    top: 385*fem,
                    child: Align(
                      child: SizedBox(
                        width: 381*fem,
                        height: 3*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffe7d1af),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupkbwrrFB (Enwe2vs5fuccF3v5XoKbWR)
                    left: 41*fem,
                    top: 513*fem,
                    child: Container(
                      width: 385*fem,
                      height: 195*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupw3tdiYH (EnweGb8zDAWZYkwaw2w3tD)
                            margin: EdgeInsets.fromLTRB(0*fem, 21*fem, 30*fem, 15*fem),
                            width: 347*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // paymentmethod11b (7:620)
                                  margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 1*fem),
                                  child: Text(
                                    'Payment Method',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xfff99601),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupkmzkGiD (EnweQFatKP7N8jubs6KmZK)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 38*fem),
                                  padding: EdgeInsets.fromLTRB(314*fem, 18*fem, 12*fem, 18*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffff1de),
                                    borderRadius: BorderRadius.circular(6*fem),
                                  ),
                                  child: Align(
                                    // polygon1Li5 (7:615)
                                    alignment: Alignment.centerRight,
                                    child: SizedBox(
                                      width: 21*fem,
                                      height: 13*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/polygon-1-gAd.png',
                                        width: 21*fem,
                                        height: 13*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogrouphkkwRUd (EnweVAcN4TQe96gMLCHKKw)
                                  width: 345*fem,
                                  height: 47*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfff99601),
                                    borderRadius: BorderRadius.circular(9*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Top Up',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // rectangle19GVF (7:599)
                            width: 8*fem,
                            height: 195*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(13*fem),
                              color: Color(0xfff99601),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // amountBMK (7:617)
                    left: 49*fem,
                    top: 438*fem,
                    child: Align(
                      child: SizedBox(
                        width: 67*fem,
                        height: 24*fem,
                        child: Text(
                          'Amount',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle4z3s (7:618)
                    left: 43*fem,
                    top: 463*fem,
                    child: Align(
                      child: SizedBox(
                        width: 345*fem,
                        height: 49*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupmqvoTy3 (EnwezQGefXMFQ1UNNBMQVo)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 15.08*fem, 0*fem),
              width: double.infinity,
              height: 72*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(8*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x1e000000),
                    offset: Offset(0*fem, -4*fem),
                    blurRadius: 6*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupnnyhJyf (EnwfzhvqJk16j1Akb4NnYH)
                    padding: EdgeInsets.fromLTRB(24*fem, 17*fem, 35*fem, 3*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupuwhwoQd (Enwf9pAdjNsPSfHjgfUWHw)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 53*fem, 2*fem),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // homesvgrepocom1H4u (7:610)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.61*fem),
                                width: 34*fem,
                                height: 27.78*fem,
                                child: Image.asset(
                                  'assets/page-1/images/home-svgrepo-com-1-fMb.png',
                                  width: 34*fem,
                                  height: 27.78*fem,
                                ),
                              ),
                              Container(
                                // home9N1 (7:592)
                                margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                                child: Text(
                                  'Home',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupzaobpyw (EnwfMJqUthmbKdjm5kZaob)
                          margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 58.2*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // datasvgrepocom1j5K (7:582)
                                width: 32*fem,
                                height: 32*fem,
                                child: Image.asset(
                                  'assets/page-1/images/data-svgrepo-com-1-8uF.png',
                                  width: 32*fem,
                                  height: 32*fem,
                                ),
                              ),
                              Text(
                                // datacuo (7:591)
                                'Data',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupyhxuLqo (EnwfVobKqWXDqkA3FFYHxu)
                          width: 31.8*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // airtimes53 (7:588)
                                left: 0.7954101562*fem,
                                top: 40*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31*fem,
                                    height: 12*fem,
                                    child: Text(
                                      'Airtime',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 8*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff26b02),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // talkingbyphonesvgrepocom17k5 (7:593)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31.59*fem,
                                    height: 40*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/talking-by-phone-svgrepo-com-1-YaV.png',
                                      width: 31.59*fem,
                                      height: 40*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupfpc9nbK (EnwfdDYe6MGyeVHaQgFpC9)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                    width: 81*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // deposittPT (7:589)
                          left: 23*fem,
                          top: 55*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 12*fem,
                              child: Text(
                                'Deposit',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // depositsvgrepocom1LmF (7:603)
                          left: 22*fem,
                          top: 20.5217285156*fem,
                          child: Align(
                            child: SizedBox(
                              width: 35*fem,
                              height: 31.96*fem,
                              child: Image.asset(
                                'assets/page-1/images/deposit-svgrepo-com-1-hvZ.png',
                                width: 35*fem,
                                height: 31.96*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle25bhB (7:616)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 81*fem,
                              height: 72*fem,
                              child: Opacity(
                                opacity: 0.17,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0x2bf99601),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup8tsus8u (Enwfq8NTfyFbVXTjRV8tSu)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // logoutsvgrepocom1BQV (7:600)
                          margin: EdgeInsets.fromLTRB(6.08*fem, 0*fem, 0*fem, 4.63*fem),
                          width: 30.83*fem,
                          height: 27.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/log-out-svgrepo-com-1-MYm.png',
                            width: 30.83*fem,
                            height: 27.75*fem,
                          ),
                        ),
                        Text(
                          // logoutTcu (7:590)
                          'Log out',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 8*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}