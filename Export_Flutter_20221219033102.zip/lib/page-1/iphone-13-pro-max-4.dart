import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // iphone13promax4MVB (1:458)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xffffffff),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                // autogroupgukbory (EnwBTGzCJSYZPaXKdKGUKB)
                width: double.infinity,
                height: 854*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // autogroup5xuhJYq (Enw6T5zPdh8EFDAdHd5xUh)
                      left: 14*fem,
                      top: 99*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(82*fem, 82*fem, 36*fem, 50*fem),
                        width: 399*fem,
                        height: 256*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(13*fem),
                          gradient: LinearGradient (
                            begin: Alignment(-1, -0.91),
                            end: Alignment(1, 1),
                            colors: <Color>[Color(0xfff99601), Color(0xc6fc8d36), Color(0xfff26b02), Color(0xfff26b02)],
                            stops: <double>[0, 0.412, 0.723, 1],
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // autogrouponcqEau (Enw6jkBJPUAkunDsvSonCq)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                              width: double.infinity,
                              height: 86*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    // 7ub (1:481)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                                    child: Text(
                                      '\$',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 32*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // autogroupauymyS1 (Enw6rf9SwZERA3gTYcAuYM)
                                    width: 257*fem,
                                    height: double.infinity,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // walletbalancetJ5 (1:460)
                                          left: 32*fem,
                                          top: 0*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 125*fem,
                                              height: 24*fem,
                                              child: Text(
                                                'Wallet Balance',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // 8y7 (1:477)
                                          left: 0*fem,
                                          top: 18*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 257*fem,
                                              height: 68*fem,
                                              child: RichText(
                                                text: TextSpan(
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 40*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                  children: [
                                                    TextSpan(
                                                      text: '34,649',
                                                      style: SafeGoogleFont (
                                                        'Impact',
                                                        fontSize: 58*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1625*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: '.',
                                                      style: SafeGoogleFont (
                                                        'Impact',
                                                        fontSize: 40*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1625*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: '60',
                                                      style: SafeGoogleFont (
                                                        'Impact',
                                                        fontSize: 32*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1625*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupxmqtiTT (Enw759ndWPWp9yUQ2DxmqT)
                              margin: EdgeInsets.fromLTRB(65*fem, 0*fem, 106*fem, 0*fem),
                              width: double.infinity,
                              height: 29*fem,
                              decoration: BoxDecoration (
                                color: Color(0xfff8b551),
                                borderRadius: BorderRadius.circular(13*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Top Up',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // autogroupneu9XA1 (Enw7JPuZdMLMVcmmojnEU9)
                      left: 15*fem,
                      top: 423*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(72*fem, 3*fem, 3*fem, 2*fem),
                        width: 397*fem,
                        height: 52*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(13*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // purchaseKLm (1:484)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 1*fem),
                              child: Text(
                                'Purchase',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff99601),
                                ),
                              ),
                            ),
                            Container(
                              // autogroup6n8h1Db (Enw7iJPQ53uGn74uku6n8H)
                              width: 195*fem,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0xfff99601),
                                borderRadius: BorderRadius.circular(13*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Deposit ',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // historyfJ9 (1:485)
                      left: 25*fem,
                      top: 396*fem,
                      child: Align(
                        child: SizedBox(
                          width: 59*fem,
                          height: 24*fem,
                          child: Text(
                            ' History',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff99601),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // autogroupvxub7fw (Enw6AWdgANhPB44CaLvXuB)
                      left: 347*fem,
                      top: 23*fem,
                      child: Container(
                        width: 59*fem,
                        height: 57*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse3zzd (1:482)
                              left: 2*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 57*fem,
                                  height: 57*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(28.5*fem),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/ellipse-3-bg.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // ellipse4r1F (2:2)
                              left: 0*fem,
                              top: 35*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 20*fem,
                                  height: 20*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                      color: Color(0xff28e824),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x3f000000),
                                          offset: Offset(0*fem, 4*fem),
                                          blurRadius: 2*fem,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // line4VK7 (2:4)
                      left: 26*fem,
                      top: 385*fem,
                      child: Align(
                        child: SizedBox(
                          width: 381*fem,
                          height: 3*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffe7d1af),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // autogroupzynmxTb (Enw7moHZzKjwhSmcXkZYNM)
                      left: 14*fem,
                      top: 499*fem,
                      child: Container(
                        width: 412*fem,
                        height: 209*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              // autogroupjewb3V3 (Enw7uxidoJ2qquQb15JewB)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 9*fem),
                              width: 392*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group2jMs (2:19)
                                    padding: EdgeInsets.fromLTRB(29*fem, 15*fem, 20*fem, 10*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xfffff1de),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // airtimeo6q (2:13)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 1*fem),
                                          child: Text(
                                            'Airtime',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // UCy (2:17)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                                          child: Text(
                                            '3485001',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // autogrouppumkA5o (Enw8ACouKmEaJW3ss7puMK)
                                          margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 39*fem, 0*fem),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // fHT (2:15)
                                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                                child: Text(
                                                  '11/11/2022',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xfff26b02),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // amkZo (2:16)
                                                '11:30:21 am',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xfff26b02),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // H3w (2:14)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                          child: Text(
                                            '4,500',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 20*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10*fem,
                                  ),
                                  Container(
                                    // group3LY1 (2:20)
                                    padding: EdgeInsets.fromLTRB(29*fem, 15*fem, 20*fem, 10*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xfffff1de),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // airtimezcZ (2:22)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 1*fem),
                                          child: Text(
                                            'Airtime',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // 58D (2:24)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                                          child: Text(
                                            '3485001',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // autogroupwgr5NND (Enw8Xn2HpcaNyRssy3WGr5)
                                          margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 39*fem, 0*fem),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // T8m (2:23)
                                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                                child: Text(
                                                  '11/11/2022',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xfff26b02),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // amjry (2:26)
                                                '11:30:21 am',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xfff26b02),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // 48Z (2:27)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                          child: Text(
                                            '4,500',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 20*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10*fem,
                                  ),
                                  Container(
                                    // group4wTF (2:28)
                                    padding: EdgeInsets.fromLTRB(29*fem, 15*fem, 20*fem, 10*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xfffff1de),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // airtimecpH (2:30)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 1*fem),
                                          child: Text(
                                            'Airtime',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // Vt5 (2:32)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                                          child: Text(
                                            '3485001',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // autogroupnvd3o85 (Enw8qMMLhSPRAYLDkrNVD3)
                                          margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 39*fem, 0*fem),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // hDT (2:31)
                                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                                child: Text(
                                                  '11/11/2022',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xfff26b02),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // amo1b (2:34)
                                                '11:30:21 am',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xfff26b02),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // XTP (2:35)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                          child: Text(
                                            '4,500',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 20*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xfff26b02),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // rectangle19DLD (2:12)
                              width: 8*fem,
                              height: 195*fem,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(13*fem),
                                color: Color(0xfff99601),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // group5XLu (2:36)
                      left: 14*fem,
                      top: 709*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(29*fem, 15*fem, 20*fem, 10*fem),
                        width: 392*fem,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfffff1de),
                          borderRadius: BorderRadius.circular(6*fem),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // airtimeZHb (2:38)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 1*fem),
                              child: Text(
                                'Airtime',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                            Container(
                              // S6V (2:40)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                              child: Text(
                                '3485001',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                            Container(
                              // autogroup9dmjj5b (EnwCozE3U5vf5ip92W9dmj)
                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 39*fem, 0*fem),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // q8d (2:39)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    child: Text(
                                      '11/11/2022',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 10*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff26b02),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // am8dX (2:42)
                                    '11:30:21 am',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xfff26b02),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // rpR (2:43)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                              child: Text(
                                '4,500',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // group6ZTw (2:44)
                      left: 14*fem,
                      top: 779*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(29*fem, 15*fem, 20*fem, 10*fem),
                        width: 392*fem,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfffff1de),
                          borderRadius: BorderRadius.circular(6*fem),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // airtimeC17 (2:46)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 1*fem),
                              child: Text(
                                'Airtime',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                            Container(
                              // Gmf (2:48)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                              child: Text(
                                '3485001',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                            Container(
                              // autogroup4jn5AMF (EnwD2eXcbqSRGUVjMD4JN5)
                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 39*fem, 0*fem),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // qyB (2:47)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    child: Text(
                                      '11/11/2022',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 10*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff26b02),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // amY6u (2:50)
                                    '11:30:21 am',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xfff26b02),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // evd (2:51)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                              child: Text(
                                '4,500',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogrouphcqhMKF (Enw9dQrvdCbvGr59GkHCQH)
                width: double.infinity,
                height: 72*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, -4*fem),
                      blurRadius: 6*fem,
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupb16qoBF (Enw9wjfj49x6og2vNTB16q)
                      width: 81*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // homei3K (3:156)
                            left: 30*fem,
                            top: 55*fem,
                            child: Align(
                              child: SizedBox(
                                width: 25*fem,
                                height: 12*fem,
                                child: Text(
                                  'Home',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // homesvgrepocom1Zpd (3:107)
                            left: 24*fem,
                            top: 23.6117248535*fem,
                            child: Align(
                              child: SizedBox(
                                width: 34*fem,
                                height: 27.78*fem,
                                child: Image.asset(
                                  'assets/page-1/images/home-svgrepo-com-1-qTP.png',
                                  width: 34*fem,
                                  height: 27.78*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle20zuw (3:157)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 81*fem,
                                height: 72*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0x2bf99601),
                                    borderRadius: BorderRadius.only (
                                      topLeft: Radius.circular(11*fem),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup6sgmfmB (EnwAoNugBecxRjRNak6sgm)
                      padding: EdgeInsets.fromLTRB(31*fem, 17*fem, 15.08*fem, 3*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogrouptevvaNM (EnwABeSDSnh6tctuYKTevV)
                            margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 55*fem, 2*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                TextButton(
                                  // datasvgrepocom1scM (2:52)
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 32*fem,
                                    height: 32*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/data-svgrepo-com-1-txR.png',
                                      width: 32*fem,
                                      height: 32*fem,
                                    ),
                                  ),
                                ),
                                Text(
                                  // dataXwo (3:155)
                                  'Data',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup7zxfrjB (EnwALPgeEyHnBy9fUT7ZXf)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 54*fem, 0*fem),
                            width: 38*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // airtimeYru (3:152)
                                  left: 4*fem,
                                  top: 40*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 31*fem,
                                      height: 12*fem,
                                      child: Text(
                                        'Airtime',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 8*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xfff26b02),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // talkingbyphonesvgrepocom1d7f (3:131)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 38*fem,
                                      height: 40*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/talking-by-phone-svgrepo-com-1-qF7.png',
                                          width: 38*fem,
                                          height: 40*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupwhcmTsP (EnwAU48YMBtamx7gQWWHCm)
                            margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 51*fem, 2*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // depositsvgrepocom1NjT (3:85)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 35*fem,
                                      height: 35*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/deposit-svgrepo-com-1-WWd.png',
                                        width: 35*fem,
                                        height: 35*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // depositDVB (3:153)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                                  child: Text(
                                    'Deposit',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 8*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xfff26b02),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupgzcyWz5 (EnwAc8jQshZoKzopxHgzcy)
                            margin: EdgeInsets.fromLTRB(0*fem, 5.63*fem, 0*fem, 2*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // logoutsvgrepocom1E9P (3:76)
                                  margin: EdgeInsets.fromLTRB(6.08*fem, 0*fem, 0*fem, 4.63*fem),
                                  width: 30.83*fem,
                                  height: 27.75*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/log-out-svgrepo-com-1.png',
                                    width: 30.83*fem,
                                    height: 27.75*fem,
                                  ),
                                ),
                                Text(
                                  // logouthYm (3:154)
                                  'Log out',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}