import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax8ZA1 (7:367)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupj5qmeSM (EnwoxPqDGL9zXRrik5j5Qm)
              width: double.infinity,
              height: 854*fem,
              child: Stack(
                children: [
                  Positioned(
                    // autogroupa9q5udB (Enwiynd6zJRdeuTiwjA9Q5)
                    left: 14*fem,
                    top: 99*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(82*fem, 82*fem, 36*fem, 50*fem),
                      width: 399*fem,
                      height: 256*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(13*fem),
                        gradient: LinearGradient (
                          begin: Alignment(-1, -0.91),
                          end: Alignment(1, 1),
                          colors: <Color>[Color(0xfff99601), Color(0xc6fc8d36), Color(0xfff26b02), Color(0xfff26b02)],
                          stops: <double>[0, 0.412, 0.723, 1],
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupiach3so (Enwjc6uviNfGLubySxiACh)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                            width: double.infinity,
                            height: 86*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // M7o (7:374)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                                  child: Text(
                                    '\$',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 32*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroup6ssoDQu (EnwjjmMppbG4vtZzP26sso)
                                  width: 257*fem,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // walletbalancewbo (7:373)
                                        left: 32*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 125*fem,
                                            height: 24*fem,
                                            child: Text(
                                              'Wallet Balance',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // bRT (7:383)
                                        left: 0*fem,
                                        top: 18*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 257*fem,
                                            height: 68*fem,
                                            child: RichText(
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 40*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: '34,649',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 58*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: '.',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 40*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: '60',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 32*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupzgamqcd (Enwk46AdFYcFTiXmUizgaM)
                            margin: EdgeInsets.fromLTRB(65*fem, 0*fem, 106*fem, 0*fem),
                            width: double.infinity,
                            height: 29*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff8b551),
                              borderRadius: BorderRadius.circular(13*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Top Up',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupeafjspD (EnwkDfiztKMkhCEneJEafj)
                    left: 15*fem,
                    top: 423*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(72*fem, 2*fem, 3*fem, 3*fem),
                      width: 397*fem,
                      height: 52*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(13*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 1*fem),
                            blurRadius: 4*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // buygmf (7:378)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 95*fem, 0*fem),
                            child: Text(
                              'Buy',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.5*ffem/fem,
                                color: Color(0xfff26b02),
                              ),
                            ),
                          ),
                          Container(
                            // autogroup4ufkwSh (EnwkQ5bKMgG5roQ53K4UFK)
                            width: 195*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff99601),
                              borderRadius: BorderRadius.circular(13*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Sell ',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupvuqvmRj (Enwmxx9ZxKTrBDhXDwVuQV)
                    left: 22*fem,
                    top: 723*fem,
                    child: Container(
                      width: 389*fem,
                      height: 47*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff99601),
                        borderRadius: BorderRadius.circular(9*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Subscribe',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupjnlhPT7 (EnwkZf9gzT1b6H76CtJNLh)
                    left: 18*fem,
                    top: 513*fem,
                    child: Container(
                      width: 408*fem,
                      height: 195*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupbkffs7P (Enwkxp9mt23N33tnr9bKfF)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                            width: 392*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // autogroupsoarkws (Enwm9yVquWUqYNZWZ4SoaR)
                                  margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 95*fem, 1*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // amountdkm (7:380)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 154*fem, 0*fem),
                                        child: Text(
                                          'Amount',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xfff99601),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // networkuyB (7:381)
                                        'Network',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xfff99601),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroups7b7SCR (EnwmJPRVZrcnU52xo1s7b7)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
                                  width: double.infinity,
                                  height: 49*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // rectangle48qw (7:420)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                                        width: 196*fem,
                                        height: 49*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(6*fem),
                                          color: Color(0xfffff1de),
                                        ),
                                      ),
                                      Container(
                                        // autogroupksthpyf (EnwmQiaH8jNfZSskxNKStH)
                                        padding: EdgeInsets.fromLTRB(133*fem, 18*fem, 15*fem, 18*fem),
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xfffff1de),
                                          borderRadius: BorderRadius.circular(6*fem),
                                        ),
                                        child: Align(
                                          // polygon1X7P (7:422)
                                          alignment: Alignment.centerRight,
                                          child: SizedBox(
                                            width: 21*fem,
                                            height: 13*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/polygon-1-22d.png',
                                              width: 21*fem,
                                              height: 13*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupsydkpMP (EnwmXJDeYyybS4Z2tMSydK)
                                  width: double.infinity,
                                  height: 71*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // phonenumberKow (7:379)
                                        left: 4*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 123*fem,
                                            height: 24*fem,
                                            child: Text(
                                              'Phone Number',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xfff99601),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // rectangle3aE5 (7:419)
                                        left: 0*fem,
                                        top: 22*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 392*fem,
                                            height: 49*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(6*fem),
                                                color: Color(0xfffff1de),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // rectangle19eDw (7:405)
                            width: 8*fem,
                            height: 195*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(13*fem),
                              color: Color(0xfff99601),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // data9gV (7:382)
                    left: 25*fem,
                    top: 396*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 24*fem,
                        child: Text(
                          'Data',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroup9yqhom3 (EnwifJ9uzRr5wFcHzw9YQH)
                    left: 348*fem,
                    top: 25*fem,
                    child: Container(
                      width: 59*fem,
                      height: 57*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse3u3P (7:384)
                            left: 2*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 57*fem,
                                height: 57*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(28.5*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-3-bg-xch.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse4Z7w (7:385)
                            left: 0*fem,
                            top: 35*fem,
                            child: Align(
                              child: SizedBox(
                                width: 20*fem,
                                height: 20*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    color: Color(0xff28e824),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // line4c6D (7:386)
                    left: 26*fem,
                    top: 385*fem,
                    child: Align(
                      child: SizedBox(
                        width: 381*fem,
                        height: 3*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffe7d1af),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupea5x61P (EnwnCn5s4VbAfkcgUGEA5X)
              padding: EdgeInsets.fromLTRB(24*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 72*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(8*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x1e000000),
                    offset: Offset(0*fem, -4*fem),
                    blurRadius: 6*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroup4n6uj4M (EnwnVbwAPBs4X9ZaxB4n6u)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 31*fem, 5*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // homesvgrepocom1E17 (7:416)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.61*fem),
                          width: 34*fem,
                          height: 27.78*fem,
                          child: Image.asset(
                            'assets/page-1/images/home-svgrepo-com-1-sJZ.png',
                            width: 34*fem,
                            height: 27.78*fem,
                          ),
                        ),
                        Container(
                          // homeu7F (7:398)
                          margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'Home',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupt4q7fVj (Enwng6dg91P5HAfhGjT4q7)
                    width: 81*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // datasvgrepocom1n4Z (7:388)
                          left: 22*fem,
                          top: 23*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/data-svgrepo-com-1-4w3.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // data2zV (7:397)
                          left: 28*fem,
                          top: 55*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20*fem,
                              height: 12*fem,
                              child: Text(
                                'Data',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle20i6d (7:418)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 81*fem,
                              height: 72*fem,
                              child: Opacity(
                                opacity: 0.17,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0x2bf99601),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupmn2mPTf (EnwoUA9G4mbaPUQcndMn2M)
                    padding: EdgeInsets.fromLTRB(31.2*fem, 17*fem, 12*fem, 3*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroup8zmshUM (EnwnqbMrVKWtvERtWm8Zms)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                          width: 31.8*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // airtimeonH (7:394)
                                left: 0.7954101562*fem,
                                top: 40*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31*fem,
                                    height: 12*fem,
                                    child: Text(
                                      'Airtime',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 8*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff26b02),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // talkingbyphonesvgrepocom1Gfs (7:399)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31.59*fem,
                                    height: 40*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/talking-by-phone-svgrepo-com-1-9f7.png',
                                      width: 31.59*fem,
                                      height: 40*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupqv9jjZT (Enwny69N2ctLKPWFbjQV9j)
                          margin: EdgeInsets.fromLTRB(0*fem, 3.52*fem, 51*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // depositsvgrepocom1qcV (7:409)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.52*fem),
                                width: 35*fem,
                                height: 31.96*fem,
                                child: Image.asset(
                                  'assets/page-1/images/deposit-svgrepo-com-1-PHK.png',
                                  width: 35*fem,
                                  height: 31.96*fem,
                                ),
                              ),
                              Container(
                                // depositJky (7:395)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                                child: Text(
                                  'Deposit',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupuqghzNu (Enwo715qzDLBgcJkJRUQGh)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // logoutsvgrepocom1VaZ (7:406)
                                margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 37*fem,
                                    height: 37*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/log-out-svgrepo-com-1-1q3.png',
                                      width: 37*fem,
                                      height: 37*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // logoutY33 (7:396)
                                'Log out',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}