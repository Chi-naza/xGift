import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax6Q6V (7:255)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupcdhjtGZ (EnwTRpNM14EHY7pf23CDhj)
              width: double.infinity,
              height: 854*fem,
              child: Stack(
                children: [
                  Positioned(
                    // autogrouphnruav5 (EnwNxSpXL6SXvWDgFfhNru)
                    left: 14*fem,
                    top: 99*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(82*fem, 82*fem, 36*fem, 50*fem),
                      width: 399*fem,
                      height: 256*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(13*fem),
                        gradient: LinearGradient (
                          begin: Alignment(-1, -0.91),
                          end: Alignment(1, 1),
                          colors: <Color>[Color(0xfff99601), Color(0xc6fc8d36), Color(0xfff26b02), Color(0xfff26b02)],
                          stops: <double>[0, 0.412, 0.723, 1],
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupfxdk6X3 (EnwPMrKC53KMeWqrfZfXdK)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                            width: double.infinity,
                            height: 86*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // NjT (7:262)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                                  child: Text(
                                    '\$',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 32*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupiijvDzy (EnwPPMGhBJPeKwrjHMiiJV)
                                  width: 257*fem,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // walletbalanceLph (7:261)
                                        left: 32*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 125*fem,
                                            height: 24*fem,
                                            child: Text(
                                              'Wallet Balance',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // z8Z (7:271)
                                        left: 0*fem,
                                        top: 18*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 257*fem,
                                            height: 68*fem,
                                            child: RichText(
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 40*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: '34,649',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 58*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: '.',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 40*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: '60',
                                                    style: SafeGoogleFont (
                                                      'Impact',
                                                      fontSize: 32*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1625*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupndrtqB7 (EnwPXGDB8tqVhAfDz3ndRT)
                            margin: EdgeInsets.fromLTRB(65*fem, 0*fem, 106*fem, 0*fem),
                            width: double.infinity,
                            height: 29*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff8b551),
                              borderRadius: BorderRadius.circular(13*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Top Up',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroup7jxb4Jm (EnwPj6CoS4CRwntZ5K7JXb)
                    left: 15*fem,
                    top: 423*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(3*fem, 3*fem, 89*fem, 2*fem),
                      width: 397*fem,
                      height: 52*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(13*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 1*fem),
                            blurRadius: 4*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupuaphfJZ (EnwPwaqyztUpwigVYvuAph)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77*fem, 0*fem),
                            width: 195*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff99601),
                              borderRadius: BorderRadius.circular(13*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Buy',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // sellhFF (7:264)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Text(
                                'Sell ',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupbnq9A8q (EnwRYNWi85qHudiwy5BnQ9)
                    left: 22*fem,
                    top: 723*fem,
                    child: Container(
                      width: 389*fem,
                      height: 47*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff99601),
                        borderRadius: BorderRadius.circular(9*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Subscribe',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupfsj7xqP (EnwQ6VkoMzJsRtpuL9fsj7)
                    left: 18*fem,
                    top: 513*fem,
                    child: Container(
                      width: 408*fem,
                      height: 195*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupg3gdquB (EnwQUenYr3xTFiGgttG3GD)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                            width: 392*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // autogroupkxshwSR (EnwQfPyeTFKWnyDGz5KXSH)
                                  margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 95*fem, 1*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // amountqXo (7:268)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 154*fem, 0*fem),
                                        child: Text(
                                          'Amount',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xfff99601),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // network7kD (7:269)
                                        'Network',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xfff99601),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogrouptmgdEK3 (EnwQwDrcNSDDXQpGPTTMgD)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
                                  width: double.infinity,
                                  height: 49*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // rectangle4KbP (7:308)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                                        width: 196*fem,
                                        height: 49*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(6*fem),
                                          color: Color(0xfffff1de),
                                        ),
                                      ),
                                      Container(
                                        // autogroupztw3zhX (EnwR2yC2x6fKTu3H5zztw3)
                                        padding: EdgeInsets.fromLTRB(133*fem, 18*fem, 15*fem, 18*fem),
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xfffff1de),
                                          borderRadius: BorderRadius.circular(6*fem),
                                        ),
                                        child: Align(
                                          // polygon1VPP (7:310)
                                          alignment: Alignment.centerRight,
                                          child: SizedBox(
                                            width: 21*fem,
                                            height: 13*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/polygon-1-dLu.png',
                                              width: 21*fem,
                                              height: 13*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupug2vyZT (EnwR6PG1autJnpo9wJuG2V)
                                  width: double.infinity,
                                  height: 71*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // phonenumberhkM (7:267)
                                        left: 4*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 123*fem,
                                            height: 24*fem,
                                            child: Text(
                                              'Phone Number',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xfff99601),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // rectangle3xRP (7:307)
                                        left: 0*fem,
                                        top: 22*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 392*fem,
                                            height: 49*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(6*fem),
                                                color: Color(0xfffff1de),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // rectangle19dGd (7:293)
                            width: 8*fem,
                            height: 195*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(13*fem),
                              color: Color(0xfff99601),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // datajKf (7:270)
                    left: 25*fem,
                    top: 396*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 24*fem,
                        child: Text(
                          'Data',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupr9z9abB (EnwNfhoRHrnKfXDbhJR9z9)
                    left: 348*fem,
                    top: 23*fem,
                    child: Container(
                      width: 59*fem,
                      height: 57*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse3saH (7:272)
                            left: 2*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 57*fem,
                                height: 57*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(28.5*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-3-bg-FWZ.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse4jMb (7:273)
                            left: 0*fem,
                            top: 35*fem,
                            child: Align(
                              child: SizedBox(
                                width: 20*fem,
                                height: 20*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    color: Color(0xff28e824),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // line4Mtm (7:274)
                    left: 26*fem,
                    top: 385*fem,
                    child: Align(
                      child: SizedBox(
                        width: 381*fem,
                        height: 3*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffe7d1af),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupgrxu3Wh (EnwRnhSAw1ehxeK4kfGRxu)
              padding: EdgeInsets.fromLTRB(24*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 72*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(8*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x1e000000),
                    offset: Offset(0*fem, -4*fem),
                    blurRadius: 6*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupnfs9gZf (EnwS5mn475mebH6T1CnFS9)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 5*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // homesvgrepocom1NxH (7:304)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.61*fem),
                          width: 34*fem,
                          height: 27.78*fem,
                          child: Image.asset(
                            'assets/page-1/images/home-svgrepo-com-1-ApR.png',
                            width: 34*fem,
                            height: 27.78*fem,
                          ),
                        ),
                        Container(
                          // home3Yd (7:286)
                          margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'Home',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupiwjyiuf (EnwSGMJm9MuLwi9PFJiwJy)
                    width: 81*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // datasvgrepocom1Sqf (7:276)
                          left: 24*fem,
                          top: 23*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/data-svgrepo-com-1-NJu.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // dataV3F (7:285)
                          left: 30*fem,
                          top: 55*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20*fem,
                              height: 12*fem,
                              child: Text(
                                'Data',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle259tV (7:560)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 81*fem,
                              height: 72*fem,
                              child: Opacity(
                                opacity: 0.17,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0x2bf99601),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupaamfQ3j (EnwSqfgaeuzQGrFtWxAamF)
                    padding: EdgeInsets.fromLTRB(33.2*fem, 17*fem, 12*fem, 3*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupwf4mHdK (EnwSRBPPE17hqULy6ywF4m)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                          width: 31.8*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // airtimeBTo (7:282)
                                left: 0.7954101562*fem,
                                top: 40*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31*fem,
                                    height: 12*fem,
                                    child: Text(
                                      'Airtime',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 8*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfff26b02),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // talkingbyphonesvgrepocom1Egy (7:287)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31.59*fem,
                                    height: 40*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/talking-by-phone-svgrepo-com-1-jB7.png',
                                      width: 31.59*fem,
                                      height: 40*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroup8gvmu2R (EnwSffyEbrAV5Jpjjf8gvm)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 51*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // depositsvgrepocom1CGR (7:297)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/deposit-svgrepo-com-1-i2d.png',
                                      width: 35*fem,
                                      height: 35*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // deposit3H3 (7:283)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                                child: Text(
                                  'Deposit',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 8*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfff26b02),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupm1cmXi1 (EnwSofjuquE22wa4Mtm1CM)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // logoutsvgrepocom1S4H (7:294)
                                margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 37*fem,
                                    height: 37*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/log-out-svgrepo-com-1-Zz1.png',
                                      width: 37*fem,
                                      height: 37*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // logoutew3 (7:284)
                                'Log out',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}