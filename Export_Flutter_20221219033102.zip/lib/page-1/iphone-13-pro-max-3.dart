import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428.2546386719;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax3LEm (1:424)
        padding: EdgeInsets.fromLTRB(38*fem, 0*fem, 0*fem, 124*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupolufa97 (Enw4rJKfWVmmHJ8AsUoLuF)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 61.51*fem),
              width: double.infinity,
              height: 246.49*fem,
              child: Stack(
                children: [
                  Positioned(
                    // line1qqj (1:442)
                    left: 0*fem,
                    top: 207*fem,
                    child: Align(
                      child: SizedBox(
                        width: 351*fem,
                        height: 2*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle9tZ7 (1:443)
                    left: 172*fem,
                    top: 170*fem,
                    child: Align(
                      child: SizedBox(
                        width: 179*fem,
                        height: 37*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // signupaB3 (1:444)
                    left: 52*fem,
                    top: 180*fem,
                    child: Align(
                      child: SizedBox(
                        width: 58*fem,
                        height: 19*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            'Sign Up',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2449999491*ffem/fem,
                              color: Color(0xfff99601),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // signinCTK (1:445)
                    left: 243*fem,
                    top: 180*fem,
                    child: Align(
                      child: SizedBox(
                        width: 52*fem,
                        height: 19*fem,
                        child: Text(
                          'Sign In',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vector1rnm (1:455)
                    left: 116*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 274.25*fem,
                        height: 246.49*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-1.png',
                          width: 274.25*fem,
                          height: 246.49*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse1jLm (1:456)
                    left: 269*fem,
                    top: 36*fem,
                    child: Align(
                      child: SizedBox(
                        width: 91*fem,
                        height: 89*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-1-aJ5.png',
                          width: 91*fem,
                          height: 89*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse2btm (1:457)
                    left: 291*fem,
                    top: 57*fem,
                    child: Align(
                      child: SizedBox(
                        width: 48*fem,
                        height: 47*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-2.png',
                          width: 48*fem,
                          height: 47*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupnnwmVDT (Enw57D4VJdtxVCL57snnWM)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.25*fem, 31*fem),
              width: 349*fem,
              height: 68*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle3Bc5 (1:429)
                    left: 0*fem,
                    top: 17*fem,
                    child: Align(
                      child: SizedBox(
                        width: 349*fem,
                        height: 51*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // emailaddressT3o (1:436)
                    left: 4.5*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 110*fem,
                        height: 19*fem,
                        child: Text(
                          'Email address',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // passwordJq7 (1:438)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 298.25*fem, 1*fem),
              child: Text(
                'Password',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2449999491*ffem/fem,
                  color: Color(0xfff26b02),
                ),
              ),
            ),
            Container(
              // rectangle5oG5 (1:430)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32.25*fem, 9*fem),
              width: 344*fem,
              height: 51*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(8*fem),
                color: Color(0xfffff1de),
              ),
            ),
            Container(
              // forgotpassword6W5 (1:441)
              margin: EdgeInsets.fromLTRB(174.75*fem, 0*fem, 0*fem, 208*fem),
              child: Text(
                'Forgot Password?',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2449999491*ffem/fem,
                  color: Color(0xfff26b02),
                ),
              ),
            ),
            Container(
              // autogroupq7hjmMK (Enw5ENXDi6ofWhd8Wfq7Hj)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39.25*fem, 9*fem),
              width: 335*fem,
              height: 60*fem,
              decoration: BoxDecoration (
                color: Color(0xfff99601),
                borderRadius: BorderRadius.circular(9*fem),
              ),
              child: Center(
                child: Text(
                  'Get Started',
                  style: SafeGoogleFont (
                    'Poppins',
                    fontSize: 16*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.5*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Container(
              // signupa3s (1:449)
              margin: EdgeInsets.fromLTRB(232.75*fem, 0*fem, 0*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  'Sign Up',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Poppins',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.2449999491*ffem/fem,
                    color: Color(0xfff26b02),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}