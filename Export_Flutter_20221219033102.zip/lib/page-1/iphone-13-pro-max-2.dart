import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax2n1o (1:202)
        padding: EdgeInsets.fromLTRB(38*fem, 0*fem, 0*fem, 128*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupb9iyMj7 (Enw2ZwxXbLC3VH5EwtB9iy)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              width: double.infinity,
              height: 254*fem,
              child: Stack(
                children: [
                  Positioned(
                    // firstname2qF (1:408)
                    left: 2*fem,
                    top: 234*fem,
                    child: Align(
                      child: SizedBox(
                        width: 84*fem,
                        height: 19*fem,
                        child: Text(
                          'First Name',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // surmameFi1 (1:409)
                    left: 192*fem,
                    top: 234*fem,
                    child: Align(
                      child: SizedBox(
                        width: 77*fem,
                        height: 19*fem,
                        child: Text(
                          'Surmame',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line1unZ (1:415)
                    left: 0*fem,
                    top: 207*fem,
                    child: Align(
                      child: SizedBox(
                        width: 351*fem,
                        height: 2*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle9Nw3 (1:416)
                    left: 0*fem,
                    top: 170*fem,
                    child: Align(
                      child: SizedBox(
                        width: 179*fem,
                        height: 37*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // signupgB3 (1:414)
                    left: 52*fem,
                    top: 180*fem,
                    child: Align(
                      child: SizedBox(
                        width: 58*fem,
                        height: 19*fem,
                        child: Text(
                          'Sign Up',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // signinkwb (1:417)
                    left: 243*fem,
                    top: 180*fem,
                    child: Align(
                      child: SizedBox(
                        width: 52*fem,
                        height: 19*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            'Sign In',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2449999491*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vector116q (1:452)
                    left: 116*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 274.25*fem,
                        height: 246.49*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-1-gt1.png',
                          width: 274.25*fem,
                          height: 246.49*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse14qo (1:453)
                    left: 269*fem,
                    top: 35*fem,
                    child: Align(
                      child: SizedBox(
                        width: 91*fem,
                        height: 89*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-1.png',
                          width: 91*fem,
                          height: 89*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse2M4D (1:454)
                    left: 291*fem,
                    top: 56*fem,
                    child: Align(
                      child: SizedBox(
                        width: 48*fem,
                        height: 47*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-2-uFX.png',
                          width: 48*fem,
                          height: 47*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupxrahEdo (Enw2nXRuSd685cp1M3XRAh)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 39*fem, 21*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // rectangle4Lwj (1:403)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33*fem, 0*fem),
                    width: 157*fem,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                      color: Color(0xfffff1de),
                    ),
                  ),
                  Container(
                    // rectangle2Qwb (1:400)
                    width: 159*fem,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                      color: Color(0xfffff1de),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupg6nd8Mo (Enw2yX7auCJEQ7b5CsG6nd)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 15*fem),
              width: 349*fem,
              height: 68*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle3pEd (1:402)
                    left: 0*fem,
                    top: 17*fem,
                    child: Align(
                      child: SizedBox(
                        width: 349*fem,
                        height: 51*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // emailaddressuG5 (1:410)
                    left: 4.5*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 110*fem,
                        height: 19*fem,
                        child: Text(
                          'Email address',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupuqyr9gD (Enw38MCCyqWbHsnf4YUQYR)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 35*fem, 15*fem),
              width: 347*fem,
              height: 69*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle52k1 (1:404)
                    left: 3*fem,
                    top: 18*fem,
                    child: Align(
                      child: SizedBox(
                        width: 344*fem,
                        height: 51*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // phonenumberi73 (1:411)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 115*fem,
                        height: 19*fem,
                        child: Text(
                          'Phone Number',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2449999491*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup1wrmBFX (Enw3GvnFD6suQQ9m9b1WrM)
              margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 64*fem, 1*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // password5rh (1:412)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 106*fem, 0*fem),
                    child: Text(
                      'Password',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2449999491*ffem/fem,
                        color: Color(0xfff26b02),
                      ),
                    ),
                  ),
                  Text(
                    // confirmpaswordyhB (1:413)
                    'Confirm Pasword',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.2449999491*ffem/fem,
                      color: Color(0xfff26b02),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupze1fh7P (Enw3RRY69udXvWa3K5zE1f)
              margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 39*fem, 16*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // rectangle6Pku (1:405)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                    width: 157*fem,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                      color: Color(0xfffff1de),
                    ),
                  ),
                  Container(
                    // rectangle7JN5 (1:406)
                    width: 157*fem,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                      color: Color(0xfffff1de),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // countryctZ (1:418)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 294*fem, 3*fem),
              child: Text(
                'Country',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2449999491*ffem/fem,
                  color: Color(0xfff26b02),
                ),
              ),
            ),
            Container(
              // autogroup7koouMs (Enw3aqS5Dm9fyAPQda7Koo)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 61*fem),
              padding: EdgeInsets.fromLTRB(18*fem, 18*fem, 26*fem, 14*fem),
              decoration: BoxDecoration (
                color: Color(0xfffff1de),
                borderRadius: BorderRadius.circular(8*fem),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // line2ZxD (1:422)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                    width: 73*fem,
                    height: 1*fem,
                    decoration: BoxDecoration (
                      color: Color(0xfff26b02),
                    ),
                  ),
                  Container(
                    // choosecountry5Qm (1:419)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                    child: Text(
                      'Choose Country',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2449999491*ffem/fem,
                        color: Color(0xfff26b02),
                      ),
                    ),
                  ),
                  Container(
                    // line3m2h (1:423)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                    width: 52*fem,
                    height: 1*fem,
                    decoration: BoxDecoration (
                      color: Color(0xfff26b02),
                    ),
                  ),
                  Container(
                    // polygon1Gk9 (1:420)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                    width: 21*fem,
                    height: 13*fem,
                    child: Image.asset(
                      'assets/page-1/images/polygon-1-TQD.png',
                      width: 21*fem,
                      height: 13*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup1zq9NHP (Enw3oVjeMWfS9v4zxH1zQ9)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39*fem, 5*fem),
              width: 335*fem,
              height: 60*fem,
              decoration: BoxDecoration (
                color: Color(0xfff99601),
                borderRadius: BorderRadius.circular(9*fem),
              ),
              child: Center(
                child: Text(
                  'Get Started',
                  style: SafeGoogleFont (
                    'Poppins',
                    fontSize: 16*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.5*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Container(
              // signinCGR (1:450)
              margin: EdgeInsets.fromLTRB(240*fem, 0*fem, 0*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  'Sign In',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Poppins',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.2449999491*ffem/fem,
                    color: Color(0xfff26b02),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}