import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13promax9SZX (7:479)
        padding: EdgeInsets.fromLTRB(0*fem, 36*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogrouprxchgTs (Enwrju2SW74dywkqn7rxcH)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 5*fem),
              width: 59*fem,
              height: 57*fem,
              child: Stack(
                children: [
                  Positioned(
                    // ellipse3NLh (7:496)
                    left: 2*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 57*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(28.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-3-bg-bkD.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse4Q2V (7:497)
                    left: 0*fem,
                    top: 35*fem,
                    child: Align(
                      child: SizedBox(
                        width: 20*fem,
                        height: 20*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xff28e824),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup37db1ny (Enws8tN8pks3jtetaJ37db)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
              width: double.infinity,
              height: 753*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle10529 (7:480)
                    left: 14*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 399*fem,
                        height: 256*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(13*fem),
                            gradient: LinearGradient (
                              begin: Alignment(-1, -0.91),
                              end: Alignment(1, 1),
                              colors: <Color>[Color(0xfff99601), Color(0xc6fc8d36), Color(0xfff26b02), Color(0xfff26b02)],
                              stops: <double>[0, 0.412, 0.723, 1],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle11ejT (7:481)
                    left: 15*fem,
                    top: 324*fem,
                    child: Align(
                      child: SizedBox(
                        width: 397*fem,
                        height: 52*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(13*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 1*fem),
                                blurRadius: 4*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle12VEH (7:482)
                    left: 214*fem,
                    top: 326*fem,
                    child: Align(
                      child: SizedBox(
                        width: 195*fem,
                        height: 47*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(13*fem),
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle21y9T (7:483)
                    left: 22*fem,
                    top: 624*fem,
                    child: Align(
                      child: SizedBox(
                        width: 389*fem,
                        height: 47*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(9*fem),
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle13Fcm (7:484)
                    left: 161*fem,
                    top: 177*fem,
                    child: Align(
                      child: SizedBox(
                        width: 110*fem,
                        height: 29*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(13*fem),
                            color: Color(0xfff8b551),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // walletbalanceLeD (7:485)
                    left: 152*fem,
                    top: 82*fem,
                    child: Align(
                      child: SizedBox(
                        width: 125*fem,
                        height: 24*fem,
                        child: Text(
                          'Wallet Balance',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ba9 (7:486)
                    left: 96*fem,
                    top: 113*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 48*fem,
                        child: Text(
                          '\$',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // topupqzH (7:487)
                    left: 188*fem,
                    top: 179*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 24*fem,
                        child: Text(
                          'Top Up',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // sell5Nq (7:488)
                    left: 290*fem,
                    top: 338*fem,
                    child: Align(
                      child: SizedBox(
                        width: 33*fem,
                        height: 24*fem,
                        child: Text(
                          'Sell ',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subscribewA9 (7:489)
                    left: 182*fem,
                    top: 640*fem,
                    child: Align(
                      child: SizedBox(
                        width: 83*fem,
                        height: 24*fem,
                        child: Text(
                          'Subscribe',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // buyPnq (7:490)
                    left: 87*fem,
                    top: 338*fem,
                    child: Align(
                      child: SizedBox(
                        width: 32*fem,
                        height: 24*fem,
                        child: Text(
                          'Buy',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // phonenumberH7X (7:491)
                    left: 22*fem,
                    top: 514*fem,
                    child: Align(
                      child: SizedBox(
                        width: 123*fem,
                        height: 24*fem,
                        child: Text(
                          'Phone Number',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // amountxjT (7:492)
                    left: 24*fem,
                    top: 414*fem,
                    child: Align(
                      child: SizedBox(
                        width: 67*fem,
                        height: 24*fem,
                        child: Text(
                          'Amount',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // networkcJD (7:493)
                    left: 245*fem,
                    top: 414*fem,
                    child: Align(
                      child: SizedBox(
                        width: 70*fem,
                        height: 24*fem,
                        child: Text(
                          'Network',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // dataVso (7:494)
                    left: 25*fem,
                    top: 297*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 24*fem,
                        child: Text(
                          'Data',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // Bkd (7:495)
                    left: 120*fem,
                    top: 100*fem,
                    child: Align(
                      child: SizedBox(
                        width: 257*fem,
                        height: 68*fem,
                        child: RichText(
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 40*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                            children: [
                              TextSpan(
                                text: '34,649',
                                style: SafeGoogleFont (
                                  'Impact',
                                  fontSize: 58*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                              TextSpan(
                                text: '.',
                                style: SafeGoogleFont (
                                  'Impact',
                                  fontSize: 40*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                              TextSpan(
                                text: '60',
                                style: SafeGoogleFont (
                                  'Impact',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line4ccy (7:498)
                    left: 26*fem,
                    top: 286*fem,
                    child: Align(
                      child: SizedBox(
                        width: 381*fem,
                        height: 3*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffe7d1af),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle19hPX (7:517)
                    left: 418*fem,
                    top: 414*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 195*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(13*fem),
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle3nA5 (7:531)
                    left: 18*fem,
                    top: 536*fem,
                    child: Align(
                      child: SizedBox(
                        width: 392*fem,
                        height: 49*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle44tH (7:532)
                    left: 18*fem,
                    top: 439*fem,
                    child: Align(
                      child: SizedBox(
                        width: 196*fem,
                        height: 49*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5ARX (7:533)
                    left: 241*fem,
                    top: 439*fem,
                    child: Align(
                      child: SizedBox(
                        width: 169*fem,
                        height: 49*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xfffff1de),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // polygon12Tj (7:534)
                    left: 374*fem,
                    top: 457*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 13*fem,
                        child: Image.asset(
                          'assets/page-1/images/polygon-1-XXf.png',
                          width: 21*fem,
                          height: 13*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle227VB (7:535)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 428*fem,
                        height: 753*fem,
                        child: Opacity(
                          opacity: 0.62,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0x9e944609),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle23Ng1 (7:536)
                    left: 20*fem,
                    top: 237*fem,
                    child: Align(
                      child: SizedBox(
                        width: 395*fem,
                        height: 299*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(11*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle24Fjo (7:537)
                    left: 64*fem,
                    top: 475*fem,
                    child: Align(
                      child: SizedBox(
                        width: 316*fem,
                        height: 47*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(9*fem),
                            color: Color(0xfff99601),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // confirmYD7 (7:538)
                    left: 180*fem,
                    top: 488*fem,
                    child: Align(
                      child: SizedBox(
                        width: 68*fem,
                        height: 24*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            'Confirm',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // recharge2500to08123456789bhB (7:539)
                    left: 148.5*fem,
                    top: 381*fem,
                    child: Align(
                      child: SizedBox(
                        width: 154*fem,
                        height: 60*fem,
                        child: RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                            children: [
                              TextSpan(
                                text: 'Recharge ',
                              ),
                              TextSpan(
                                text: '2500',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                              TextSpan(
                                text: ' to\n',
                              ),
                              TextSpan(
                                text: '08123456789',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // faqsvgrepocom1Kv1 (7:540)
                    left: 181*fem,
                    top: 272*fem,
                    child: Align(
                      child: SizedBox(
                        width: 90*fem,
                        height: 90*fem,
                        child: Image.asset(
                          'assets/page-1/images/faq-svgrepo-com-1.png',
                          width: 90*fem,
                          height: 90*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupyrarCD7 (EnwswhMUJechBuuFQ5yRAR)
              padding: EdgeInsets.fromLTRB(24*fem, 1*fem, 15.08*fem, 0*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(8*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x1e000000),
                    offset: Offset(0*fem, -4*fem),
                    blurRadius: 6*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupfdc5R5s (EnwtGSKF9u3HgobA7WfDc5)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 6*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // homesvgrepocom1umj (7:528)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.61*fem),
                          width: 34*fem,
                          height: 27.78*fem,
                          child: Image.asset(
                            'assets/page-1/images/home-svgrepo-com-1-jQd.png',
                            width: 34*fem,
                            height: 27.78*fem,
                          ),
                        ),
                        Container(
                          // homePS1 (7:510)
                          margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'Home',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupfwbbGkh (EnwtSWrnVRUtUky8pMFWbB)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30.2*fem, 0*fem),
                    width: 81*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // datasvgrepocom1xNd (7:500)
                          left: 21*fem,
                          top: 22*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/data-svgrepo-com-1-ad7.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // datacCH (7:509)
                          left: 27*fem,
                          top: 54*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20*fem,
                              height: 12*fem,
                              child: Text(
                                'Data',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff26b02),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle25GGq (7:557)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 81*fem,
                              height: 72*fem,
                              child: Opacity(
                                opacity: 0.17,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0x2bf99601),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup91nqXTf (EnwtbbRzRSYJ9m1CSf91nq)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 4*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // talkingbyphonesvgrepocom1Ess (7:511)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.2*fem, 0*fem),
                          width: 31.59*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/talking-by-phone-svgrepo-com-1-v81.png',
                            width: 31.59*fem,
                            height: 40*fem,
                          ),
                        ),
                        Container(
                          // airtimeuz1 (7:506)
                          margin: EdgeInsets.fromLTRB(0.8*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'Airtime',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupzkoxnH7 (Enwtk1Me5ngF5TUegcZKoX)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 51*fem, 6*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // depositsvgrepocom1VSR (7:521)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.52*fem),
                          width: 35*fem,
                          height: 31.96*fem,
                          child: Image.asset(
                            'assets/page-1/images/deposit-svgrepo-com-1-vHf.png',
                            width: 35*fem,
                            height: 31.96*fem,
                          ),
                        ),
                        Container(
                          // depositv1w (7:507)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                          child: Text(
                            'Deposit',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xfff26b02),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupa3jxCEM (EnwtsFeZmiCdhNiXzxA3jX)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // logoutsvgrepocom1JoB (7:518)
                          margin: EdgeInsets.fromLTRB(6.08*fem, 0*fem, 0*fem, 4.63*fem),
                          width: 30.83*fem,
                          height: 27.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/log-out-svgrepo-com-1-M4u.png',
                            width: 30.83*fem,
                            height: 27.75*fem,
                          ),
                        ),
                        Text(
                          // logoutnTT (7:508)
                          'Log out',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 8*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff26b02),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}